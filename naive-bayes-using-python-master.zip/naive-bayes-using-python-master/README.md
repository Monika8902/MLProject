# naive-bayes-using-python

1. Download pandas library of python
	(pip install pandas)

2. Edit the csv file name in the python code according to your need.
	(at line no 120 naive_bayes.py) 

3. It will run for any of the csv file with n number of data and coloumn
	(Complete Dynamic code.)

5. Also work for Laplacian Smoothing. No worry!

4. Have fun!
